# Complete Example of Offline Quantification
