# Architecting

| ![img](../images/architecture.png) |
| ------------------------------------------------------------ |
| Figure 1. Architecting                                       |